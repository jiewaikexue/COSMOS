#ifndef CMCTL_H
#define CMCTL_H
#include "type.h"
#include "ldrtype.h"
#include "imgmgrhead.h"
#include "vgastr_t.h"
#include "fs.h"
#include "realparm.h"
#include "chkcpmm_t.h"
#include "io.h"
#include "vgastr.h"
#include "inithead.h"
#include "ldrkrlentry.h"
#include "chkcpmm.h"
#include "graph.h"
#include "bstartparm.h"
#endif
