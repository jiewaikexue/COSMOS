/**********************************************************
        基本数据类型文件bastype.h
***********************************************************
                彭东
**********************************************************/
#ifndef _BASTYPE_H
#define _BASTYPE_H
#include "bastype_t.h"
#include "list_t.h"
#include "spinlock_t.h"
#include "sem_t.h"

#include "list.h"
#endif
