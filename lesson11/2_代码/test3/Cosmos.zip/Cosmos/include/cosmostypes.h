/****************************************************************
        Cosmos全局类型控制头文件cosmostypes.h
*****************************************************************
                彭东
****************************************************************/
#ifndef _COSMOSTYPES_H
#define _COSMOSTYPES_H
#include "config.h"
#include "bastype.h"
#include "haltypes.h"
#endif
