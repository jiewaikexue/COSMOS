/**********************************************************
        物理内存管理器类型头文件memmgrtypes.h
***********************************************************
                彭东 
**********************************************************/
#ifndef _MEMMGRTYPES_H
#define _MEMMGRTYPES_H
#include "msadsc_t.h"
#include "memarea_t.h"
#include "memdivmer_t.h"
#include "kmsob_t.h"
#include "memmgrinit_t.h"
#endif // MEMMGRTYPES_H
