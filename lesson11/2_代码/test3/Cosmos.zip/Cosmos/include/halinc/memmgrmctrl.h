/**********************************************************
        物理内存管理器主控头文件memmgrmctrl.h
***********************************************************
                彭东
**********************************************************/
#ifndef _MEMMGRMCTRL_H
#define _MEMMGRMCTRL_H

#include "msadsc.h"
#include "memarea.h"
#include "memdivmer.h"
#include "kmsob.h"
#include "memmgrinit.h"

#endif // MEMMGRMCTRL_H
